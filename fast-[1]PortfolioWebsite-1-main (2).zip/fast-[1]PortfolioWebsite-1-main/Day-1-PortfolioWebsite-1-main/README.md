# Day-1-PortfolioWebsite - 1

Embark on an exhilarating journey of web development with the "100 Days, 100 Websites" challenge! Over the course of 100 days, immerse yourself in the world of HTML, CSS, and JavaScript as you craft 100 unique websites from scratch. Each day presents an opportunity to explore new design concepts, master coding techniques, and unleash your creativity.

Live Demo - https://quantumcoding123.github.io/Day-1-PortfolioWebsite-1/

# Join Us

GitHub-https://github.com/QuantumCoding123

Instagram - https://www.instagram.com/khandhalabhaumik?igsh=MWxzeDR5M3QwMXV1cw==

Telegram-https://t.me/+yw9iQAMmd002NTI1

Whatsapp- https://whatsapp.com/channel/0029VaVInCA2ZjCjXEf2IC2I

With a plethora of free resources available online, including tutorials, code snippets, and open-source projects, you'll have everything you need to bring your ideas to life. Whether you're building a personal blog, an e-commerce site, a portfolio showcase, or an interactive web application, the possibilities are endless.

Join the "100 Days, 100 Websites" challenge today and witness your proficiency in web development soar to new heights. With dedication, perseverance, and a dash of creativity, you'll emerge from this journey as a proficient web developer ready to tackle any project that comes your way.

# Output 1

![Screenshot (4)](https://github.com/QuantumCoding123/Day-1-PortpolioWebsite---1/assets/166281221/f0d18205-d94b-4a01-92e4-a755079c2150)


# Output 2


![Screenshot (5)](https://github.com/QuantumCoding123/Day-1-PortpolioWebsite---1/assets/166281221/ebc71298-5577-460d-8135-5b93c9a62cdb)



